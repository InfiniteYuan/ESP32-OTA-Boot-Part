#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"

#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_event_loop.h"
#include "esp_log.h"
#include "esp_ota_ops.h"
#include "esp_http_client.h"
#include "esp_https_ota.h"

#include "nvs.h"
#include "nvs_flash.h"
#include "string.h"

#define BOOTLOADER_OFFSET       0x1000
#define BOOTLOADER_PART_SIZE    (CONFIG_PARTITION_TABLE_OFFSET - BOOTLOADER_OFFSET)

static const char *TAG = "ota_boot";

extern const uint8_t new_bootloader_start[] asm("_binary_bootloader_bin_start");
extern const uint8_t new_bootloader_end[] asm("_binary_bootloader_bin_end");

esp_err_t update_bootloader()
{
    // uint8_t boot_read_buff[32] = {0};
    // ESP_ERROR_CHECK(spi_flash_read(BOOTLOADER_OFFSET, boot_read_buff, sizeof(boot_read_buff)));

    ESP_LOGW(TAG, "update Bootloader starting……");
    // if (boot_read_buff[3] != 0x20) { // SPI Flash Freq != 40MHz
        // erase bootloader
        ESP_LOGI(TAG, "erase bootloader partition: %dKB", BOOTLOADER_PART_SIZE / 1024);
        ESP_ERROR_CHECK(spi_flash_erase_range(BOOTLOADER_OFFSET, BOOTLOADER_PART_SIZE));
        // write new bootloader
        ESP_LOGI(TAG, "write new bootloader binary: %dKB", (new_bootloader_end - new_bootloader_start) / 1024);
        ESP_ERROR_CHECK(spi_flash_write(BOOTLOADER_OFFSET, new_bootloader_start, new_bootloader_end - new_bootloader_start));

        return ESP_OK;
    // }

    return EALREADY;
}

void app_main()
{
    ESP_LOGI(TAG, "app_main");

    // Initialize NVS.
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        // 1.OTA app partition table has a smaller NVS partition size than the non-OTA
        // partition table. This size mismatch may cause NVS initialization to fail.
        // 2.NVS partition contains data in new format and cannot be recognized by this version of code.
        // If this happens, we erase NVS partition and initialize NVS again.
        ESP_ERROR_CHECK(nvs_flash_erase());
        err = nvs_flash_init();
    }
    ESP_ERROR_CHECK( err );

    vTaskDelay(pdMS_TO_TICKS(1000)); // Delay 1s

    /**
     * @brief Update Bootloader.
     */
    err = update_bootloader();
    if (err == ESP_OK) {
        ESP_LOGW(TAG, "update Bootloader completed");

    } else if (err == EALREADY) {

    }
    
    /**
     * @brief Rollback to old app bin.
     */
    const esp_partition_t *running = esp_ota_get_running_partition();
    const esp_partition_t *old_app_partition = esp_ota_get_next_update_partition(NULL);

    ESP_LOGI(TAG, "Running partition type %d subtype %d at offset 0x%x",
             running->type, running->subtype, running->address);
    ESP_LOGI(TAG, "Old App partition type %d subtype %d at offset 0x%x",
             old_app_partition->type, old_app_partition->subtype, old_app_partition->address);

    err = esp_ota_set_boot_partition(old_app_partition);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "esp_ota_set_boot_partition failed (%s)!", esp_err_to_name(err));
    }

    ESP_LOGI(TAG, "Restart……");
    vTaskDelay(pdMS_TO_TICKS(100)); // Delay 100ms
    esp_restart();

    return;
}
